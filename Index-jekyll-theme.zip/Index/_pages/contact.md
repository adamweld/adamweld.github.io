---
title: Contact
subtitle: Index comes with a built-in contact form, that's free and easy to set up.
description: Index is a minimal, fixed sidebar grid portfolio Jekyll theme.
featured_image: /images/demo/demo-landscape.jpg
---

{% include contact-form.html %}

We've made a contact form that you can use with [Formspree](https://formspree.io/) to handle up to 50 submissions per month for free. You could also easily switch out the end-point to use another contact form service.